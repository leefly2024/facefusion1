MIT license

Copyright (c) 2024 Henry Ruhs
